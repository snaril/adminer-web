import { createRouter, createWebHashHistory } from 'vue-router'
import Admin from '~/layouts/admin.vue'
import Index from '~/pages/index.vue'
import Login from '~/pages/login.vue'
import NotFound from '~/pages/404.vue'
import GoodList from '~/pages/goods/list.vue'

import { defineAsyncComponent } from 'vue';



const routes = [
    {
        path: "/",
        name: "admin",
        component: Admin,

    },
    {
        path: "/login",
        component: Login,
        meta: {
            title: "登陆页面"
        }
    },
    {
        path: "/:pathMatch(.*)*",
        name: 'NotFound',
        component: NotFound,
        meta: {
            title: "404"
        }
    }
]


export const router = createRouter({
    history: createWebHashHistory(),
    routes
})


// 动态路由，用于 匹配后端菜单，动态添加路由

const asyncRoutes = [
    {
        path: "/",
        component: () => import('~/pages/index.vue'),
        meta: {
            title: "首页"
        }
    },
    {
        path: "/system/menu",
        component: () => import('~/pages/system/menu/menu.vue'),
        meta: {
            title: "菜单管理"
        }
    },
    {
        path: "/system/table",
        component: () => import('~/pages/system/table/table.vue'),
        meta: {
            title: "菜单管理"
        }
    },
    {
        path: "/goods/list",
        component: GoodList,
        meta: {
            title: "商品管理"
        }
    },


]

// function generateDynamicRoutes(backendMenu) {
//     backendMenu.forEach(menuItem => {
//         if (menuItem.frontpath) {
//             // Remove the leading slash (/) and ensure the correct path format
//             const routePath = menuItem.frontpath.replace(/^\//, '');

//             try {
//                 const route = {
//                     path: routePath === "" ? "/index" : `/${routePath}`, // Set a default component for the root path
//                     name: menuItem.name,
//                     component: defineAsyncComponent( async  () => import(/* @vite-ignore */ `/src/pages/${routePath}.vue`)), // Use import() for dynamic import
//                 };
//                 asyncRoutes.push(route);
//             } catch (error) {
//                 const route = {
//                     path: routePath === "" ? "/index" : `/${routePath}`, // Set a default component for the root path
//                     name: menuItem.name,
//                     component: defineAsyncComponent(async  () => import(/* @vite-ignore */ `../pages/404.vue`)), // Use import() for dynamic import
//                 };
//                 asyncRoutes.push(route);
//             }
//         } else {
//             generateDynamicRoutes(menuItem.child);
//         }
//     });
// }




// 动态添加路由的方法
export function addRoutes(menus) {
    // generateDynamicRoutes(menus)
    // 是否有新的路由
    let hasNewRoutes = false
    const findAndAddRoutesByMenus = (arr) => {
        arr.forEach(e => {
            console.log("forEach", e)
            let item = asyncRoutes.find(o => o.path == e.path)
            console.log("frontpath", e.path)
            console.log("item", item)
            if (item && !router.hasRoute(e.path)) {
                router.addRoute("admin", item)
                hasNewRoutes = true
            }
            if (e.children && e.children.length > 0) {
                findAndAddRoutesByMenus(e.children)
            }
        })
    }
    findAndAddRoutesByMenus(menus)

    console.log(router.getRoutes())
    return hasNewRoutes

}


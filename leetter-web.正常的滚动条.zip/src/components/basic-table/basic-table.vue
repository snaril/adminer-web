<template>
    <div class="basic-table">
      <vxe-table :data="tableData" :columns="columns">
        <vxe-toolbar slot="toolbar" @click="$event.button.name === 'add' && openModal()"></vxe-toolbar>
      </vxe-table>
  
      <vxe-modal v-model="showModal">
        <vxe-form :data="currentItem">
          <template v-for="column in columns">
            <vxe-form-item :field="column.field" :label="column.title" v-if="column.field">
              <vxe-input v-model="currentItem[column.field]"></vxe-input>
            </vxe-form-item>
          </template>
        </vxe-form>
        <template #footer>
          <vxe-button @click="save">保存</vxe-button>
        </template>
      </vxe-modal>
    </div>
  </template>
  
  <script>
  import axios from 'axios'; // 假设你正在使用axios
  
  export default {
    props: {
      columns: {
        type: Array,
        required: true
      },
      fetchApi: String,
      addApi: String,
      editApi: String,
      deleteApi: String,
    },
    data() {
      return {
        tableData: [],
        currentItem: {},
        showModal: false,
      };
    },
    created() {
      this.fetchData();
    },
    methods: {
      async fetchData() {
        try {
          const { data } = await axios.get(this.fetchApi);
          this.tableData = data;
        } catch (error) {
          console.error("Error fetching data:", error);
        }
      },
      openModal(item = {}) {
        this.currentItem = { ...item };
        this.showModal = true;
      },
      async save() {
        if (this.currentItem.id) {
          // Edit
          await axios.put(this.editApi, this.currentItem);
        } else {
          // Add
          await axios.post(this.addApi, this.currentItem);
        }
        this.fetchData();
        this.showModal = false;
      }
    }
  };
  </script>
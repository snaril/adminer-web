<!--1、修改App.vue：-->
<script setup>

</script>

<template>
<router-view></router-view>
</template>

<style scoped>

</style>

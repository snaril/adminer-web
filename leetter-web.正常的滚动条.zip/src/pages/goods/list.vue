<template>
    商品管理
</template>

<script setup>

</script>
<style lang="scss">

</style>
<template>
  <div class="flex home">
    <div class="home-left h-screen">
      <Menus />
    </div>
    <!-- g-gray-100 -->
    <div class="home-right w-full h-screen pl-5 pr-5 bg-gray-100 flex flex-col">
      <!-- <div class=" home-right-box pr-5"> -->
        <div class="h-26">
          <Header></Header>
          <Nav></Nav>
        </div>

        <div class="home-content mt-2 ml-[-0.50rem] mr-[-0.5rem] flex-auto overflow-auto bg-dark-50">
            <!-- <div class="mr-5"> -->
                <router-view></router-view>
            <!-- </div> -->
          
        </div>
      </div>
    <!-- </div> -->
  </div>
</template>
<script setup>
// import { ref, reactive } from "vue"
// import { showModeal, toast } from "~/composables/util"
import Menus from "~/layouts/menus/menus.vue";
import Header from "~/layouts/header/header.vue";
import Nav from "~/layouts/nav/nav.vue";
</script>
<style lang="scss">
.home-left {
  // width: 240px;
  min-width: 230px;
  background-color: #202123;
  font-size: 12px;
}
.home-right {
  width: calc(100% - 230px); // or any other fixed value
}
.home-right {
  scrollbar-width: thin; // for Firefox
  &::-webkit-scrollbar {
    width: 12px; // adjust as needed for other browsers like Chrome and Safari
  }
  &::-webkit-scrollbar-thumb {
    background-color: transparent; // make the thumb transparent
  }
  &:hover::-webkit-scrollbar-thumb {
    background-color: rgba(0, 0, 0, 0.5); // show the thumb on hover
  }
//   /* 设置滚动条的宽度 */
//   ::-webkit-scrollbar {
//     width: 6px;
//   }

//   /* 设置滚动条背景 */
//   ::-webkit-scrollbar-track {
//     background: #f1f1f1;
//   }

//   /* 设置垂直滚动条的滑块颜色和圆角 */
//   ::-webkit-scrollbar-thumb {
//     background: red;
//     border-radius: 5px;
//   }

//   /* 滚动条滑块悬停效果 */
//   ::-webkit-scrollbar-thumb:hover {
//     background: #555;
//   }

//   .home-content {
//     overflow-x: hidden; // 隐藏水平滚动条
//   }
}
.home-right-box {
  box-sizing: border-box;
}
</style>
